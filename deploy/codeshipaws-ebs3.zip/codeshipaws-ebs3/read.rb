data = File.read("/code/test.txt")
puts "Reading from the volume" + data
exit 0
