File.write('/code/test.txt', 'Test content')
puts "Writing to a volume!"
exit 0
