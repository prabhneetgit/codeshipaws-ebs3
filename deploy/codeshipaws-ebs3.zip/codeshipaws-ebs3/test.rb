if ENV['TEST_TOKEN'].nil?
   puts "Our Variable Is Not Working"
   exit 1
else
   puts "Our Variable Is Working"
   exit 0
 end
